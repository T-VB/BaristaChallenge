public class Item {

    //add private member variables (what object has inherintly)
    private String name;
    private double price;

    public Item(){};

    //'constructor method' within 'Item' class that takes arguments to set the name,
    //and price for that object on instantiation. (use "this dot" to clarify for that particular object)
    public Item(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() { //'getter' for name using a return and this dot
        return this.name;
    }

    public double getPrice() { //'getter' for price using a return and this dot
        return this.price;
    }
    //using data type 'void' to avoid using a return
    public void setName() { //'setter' for name using this dot 
        this.name = name;
    }
    //using data type 'void' to avoid using a return
    public void setPrice() { //'setter' for price using this dot
        this.price = price;
    }
}