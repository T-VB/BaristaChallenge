import java.util.ArrayList;
public class TestOrders {
    public static void main(String[] args) {
    //1)Set menu items/instanstiate a menu item for each item in class Item
    Item item1 = new Item("mocha", 3.75);
    Item item2 = new Item("latte", 4.25);
    Item item3 = new Item("drip coffee", 2.5);
    Item item4 = new Item("cappucino", 3.25);
    //Item item1 = new Item();
    //item1.name = "mocha";
    //item1.price = 3.75;

    //2)Create 2 orders for unspecified guests(no name)
    Order order1 = new Order();
    Order order2 = new Order();

    //2)Create 3 orders using the overload constructor (to give a name to each order)
    Order order3 = new Order("Tyler");
    Order order4 = new Order("Champ");
    Order order5 = new Order("Shiloh");

    //Add 2 items to each order
    order1.addItem(item1);
    order1.addItem(item2);
    order2.addItem(item4);
    order2.addItem(item2);
    order3.addItem(item1);
    order3.addItem(item2);
    order4.addItem(item3);
    order4.addItem(item4);
    order5.addItem(item1);
    order5.addItem(item3);


    //Test the results (by calling display method) of an order
    order3.display();

    //Test the getStatus message on a couple orders
    order1.setReady(true);
    System.out.println(order1.getStatus());
    order2.setReady(true);
    System.out.println(order2.getStatus());

    //implement the getOrderTotal method
    System.out.println(order1.getOrderTotal());
    }
}
    