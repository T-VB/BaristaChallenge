import java.util.ArrayList;
public class Order {

    //add private member variables (what object has inherently)
    private String name; //default value of null
    private boolean ready; //default value of false
    private ArrayList<Item> items = new ArrayList<Item>(); //defaults to null

    //"constructor method" without using a return and no arguments
    public Order(){
        this.name = "guest";
        this.ready = false;
    }

    //"overloaded constructor" to get custom name when used in a parameter
    public Order(String name){
        this.name = name;
        this.ready = false;
    }

    public String getName(){ //'getter' for name
        return this.name;
    }

    public boolean getReady(){ //'getter' for ready
        return this.ready;
    }

    public ArrayList<Item> getItems(){ //'getter' for items in array list
        return items;
    }

    public void setName(String name){ //'setter' for name
        this.name = name;
    }

    public void setReady(boolean ready){ //'setter' for ready
        this.ready = ready;
    }

    public void setItems(ArrayList<Item> items){ //'setter' for items in array list
        this.items = items;
    }

    public void addItem(Item item) { //add 'item' to 'items'
        this.items.add(item);
    }

    public String getStatus() { //notify customer of order status using if-statement
        if(this.ready == true) {
            return "Order is ready.";
        }
        else {
            return "Order will be ready shortly, we apologize for the delay.";
        }
    }

    public double getOrderTotal() { //notify customer of order total
        double total = 0; //set total to zero to start
        for (Item i: this.items) { //for-loop, looping through each item in ArrayList 'items'
            total += i.getPrice(); //add item price to total
        }
        return total;
    }
    
    public void display(){ //display customer info
        System.out.printf("Customer Name: %s", this.name);
    for(Item i: this.items) {
        System.out.println(i.getName() + " - $" + i.getPrice());
    }
    System.out.println("Total: $" + this.getOrderTotal());
    }
}